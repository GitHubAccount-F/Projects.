package dslabs.clientserver;

import dslabs.framework.Message;
import lombok.Data;

@Data
class Request implements Message {
  // Your code here...
}

@Data
class Reply implements Message {
  // Your code here...
}
